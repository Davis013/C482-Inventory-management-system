module davis.c482inv {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.base;
    requires javafx.graphics;

    opens davis.c482inv to javafx.fxml;
    opens davis.c482inv.models to javafx.base;
    opens davis.c482inv.Controllers to javafx.fxml;
    exports davis.c482inv.Controllers to javafx.fxml;
    exports davis.c482inv.models to javafx.base;
    exports davis.c482inv;
}
