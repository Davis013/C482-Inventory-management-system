package davis.c482inv;

import davis.c482inv.models.Inhouse;
import davis.c482inv.models.Inventory;
import davis.c482inv.models.Outsourced;
import davis.c482inv.models.Product;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * JavaFX App
 *
 * JavaDocs located under davis.c482inv/Javadoc/c482inv They're seperated between the Controllers, models, and c482inv folders.
 *
 * Error pops up if product searched on screens don't match exactly to items on list. One thing that I would add to a revised version of this project would be a listener to allow for better search functionality
 *
 * @author Brandon Davis 010008848
 */
public class App extends Application {

 @Override
    public void start(Stage stage) throws Exception {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Mainscreen.fxml"));
        Parent root = loader.load();
        stage.setTitle ( "Inventory Management System");
        stage.setScene (new Scene(root));
        stage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        //Add sample parts
        int PartsID = Inventory.getNewPartId();
        Inhouse Brakes = new Inhouse(PartsID,"Brakes", 88.99, 10, 1, 20,
                60);
        PartsID = Inventory.getNewPartId();
        Inhouse Rotors = new Inhouse(PartsID,"Rotors", 92.99, 15, 1, 30,
                61);
        PartsID = Inventory.getNewPartId();
        Inhouse Struts = new Inhouse(PartsID,"Struts", 176.99, 15, 1, 30,
                61);
        PartsID = Inventory.getNewPartId();
        Outsourced Tire = new Outsourced(PartsID, "Wrangler DuraTrac",317.00, 50, 30,
                100, "Goodyear");
        Inventory.addPart(Brakes);
        Inventory.addPart(Rotors);
        Inventory.addPart(Struts);
        Inventory.addPart(Tire);

        //Add sample product
        int ProductID = Inventory.getNewProductId();
        Product fastener = new Product(ProductID, "Wrench", 30.00, 20, 1,
                100);
        fastener.addAssociatedParts(Brakes);
        fastener.addAssociatedParts(Rotors);
        fastener.addAssociatedParts(Struts);
        fastener.addAssociatedParts(Tire);
        Inventory.addProduct(fastener);

        launch(args);
    }

}