package davis.c482inv.Controllers;

import davis.c482inv.models.Inhouse;
import davis.c482inv.models.Inventory;
import davis.c482inv.models.Outsourced;
import davis.c482inv.models.Parts;
import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Brandon Davis
 */
public class ModifypartsController implements Initializable {
    /**
     * The part object selected in the MainScreenController.
     */
    private Parts selectedPart;

    private int partID;

    /**
     * The machine ID/company name label for the part.
     */
    @FXML
    private Text PartIDLabel;


    @FXML
    private TextField IDtext;

    @FXML
    private RadioButton Inhousebutton;

    @FXML
    private TextField Invtext;

    @FXML
    private TextField MachineIDtext;

    @FXML
    private TextField Maxtext;

    @FXML
    private TextField Mintext;

    @FXML
    private TextField Nametext;

    @FXML
    private RadioButton Outsourcedbutton;

    @FXML
    private TextField Pricetext;



    /**
     * Displays confirmation dialog and loads MainScreenController.
     *
     * @param event Cancel button action.
     * @throws IOException From FXMLLoader.
     */
    @FXML
    void CancelbuttonAction(ActionEvent event) throws IOException {

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Alert");
        alert.setContentText("Would you like to cancel changes and return to the main screen?");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) {
            returnToMainScreen(event);
        }
    }
    /**
     * Switch between Machine ID and Company Name
     */

    public void radioadd(){
        if (Outsourcedbutton.isSelected())
            this.PartIDLabel.setText("Company Name");
        else
            this.PartIDLabel.setText("Machine ID");
    }

    /**
     * Replaces part in inventory and loads MainScreenController.
     * <p>
     * Text fields are validated with error messages displayed preventing empty and/or
     * invalid values.
     *
     * @param event Save button action.
     * @throws IOException From FXMLLoader.
     */
    @FXML
    void SavebuttonAction(ActionEvent event) throws IOException {

        try {
            int id = selectedPart.getId();
            String name = Nametext.getText();
            Double price = Double.parseDouble(Pricetext.getText());
            int stock = Integer.parseInt(Invtext.getText());
            int min = Integer.parseInt(Mintext.getText());
            int max = Integer.parseInt(Maxtext.getText());
            int MachineID;
            String CompanyName;
            boolean partAddSuccessful = false;

            if (minValid(min, max) && inventoryValid(min, max, stock)) {

                if (Inhousebutton.isSelected()) {
                    try {
                        MachineID = Integer.parseInt(MachineIDtext.getText());
                        Inhouse newInHousePart = new Inhouse(id, name, price, stock, min, max, MachineID);
                        Inventory.addPart(newInHousePart);
                        partAddSuccessful = true;
                    } catch (Exception e) {
                        displayAlert(2);
                    }
                }

                if (Outsourcedbutton.isSelected()) {
                    CompanyName = MachineIDtext.getText();
                    Outsourced newOutsourcedPart = new Outsourced(id, name, price, stock, min, max,
                            CompanyName);
                    Inventory.addPart(newOutsourcedPart);
                    partAddSuccessful = true;
                }

                if (partAddSuccessful) {
                    Inventory.deletePart(selectedPart);
                    returnToMainScreen(event);
                }
            }
        } catch (Exception e) {
            displayAlert(1);
        }
    }

    /**
     * Loads MainScreenController.
     *
     * @param event Passed from parent method.
     * @throws IOException From FXMLLoader.
     */
    private void returnToMainScreen(ActionEvent event) throws IOException {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Mainscreen.fxml"));
        Parent parent = loader.load();
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Validates that min is greater than 0 and less than max.
     *
     * @param min The minimum value for the part.
     * @param max The maximum value for the part.
     * @return Boolean indicating if min is valid.
     */
    private boolean minValid(int min, int max) {

        boolean isValid = true;

        if (min <= 0 || min >= max) {
            isValid = false;
            displayAlert(3);
        }

        return isValid;
    }

    /**
     * Validates that inventory level is equal too or between min and max.
     *
     * @param min   The minimum value for the part.
     * @param max   The maximum value for the part.
     * @param stock The inventory level for the part.
     * @return Boolean indicating if inventory is valid.
     */
    private boolean inventoryValid(int min, int max, int stock) {

        boolean isValid = true;

        if (stock < min || stock > max) {
            isValid = false;
            displayAlert(4);
        }

        return isValid;
    }

    /**
     * Displays various alert messages.
     *
     * @param alertType Alert message selector.
     */
    private void displayAlert(int alertType) {

        Alert alert = new Alert(Alert.AlertType.ERROR);

        switch (alertType) {
            case 1:
                alert.setTitle("Error");
                alert.setHeaderText("Error Modifying Part");
                alert.setContentText("Form contains blank fields or invalid values.");
                alert.showAndWait();
                break;
            case 2:
                alert.setTitle("Error");
                alert.setHeaderText("Invalid value for Machine ID");
                alert.setContentText("Machine ID may only contain numbers.");
                alert.showAndWait();
                break;
            case 3:
                alert.setTitle("Error");
                alert.setHeaderText("Invalid value for Min");
                alert.setContentText("Min must be a number greater than 0 and less than Max.");
                alert.showAndWait();
                break;
            case 4:
                alert.setTitle("Error");
                alert.setHeaderText("Invalid value for Inventory");
                alert.setContentText("Inventory must be a number equal to or between Min and Max");
                alert.showAndWait();
                break;
        }
    }

    /**
     * Initializes controller and populates text fields with part selected in MainScreenController.
     *
     * @param location  The location used to resolve relative paths for the root object, or null if the location is not known.
     * @param resources The resources used to localize the root object, or null if the root object was not localized.
     */
    @Override
    public void initialize(URL location, ResourceBundle resources) {

        selectedPart = MainscreenController.getPartstoModify();

        if (selectedPart instanceof Inhouse) {
            Inhousebutton.setSelected(true);
            PartIDLabel.setText("Machine ID");
            MachineIDtext.setText(String.valueOf(((Inhouse) selectedPart).getMachineID()));
        }

        if (selectedPart instanceof Outsourced) {
            Outsourcedbutton.setSelected(true);
            PartIDLabel.setText("Company Name");
            MachineIDtext.setText(((Outsourced) selectedPart).getCompanyName());
        }

        IDtext.setText(String.valueOf(selectedPart.getId()));
        Nametext.setText(selectedPart.getName());
        Invtext.setText(String.valueOf(selectedPart.getStock()));
        Pricetext.setText(String.valueOf(selectedPart.getPrice()));
        Maxtext.setText(String.valueOf(selectedPart.getMax()));
        Mintext.setText(String.valueOf(selectedPart.getMin()));



    }
}
