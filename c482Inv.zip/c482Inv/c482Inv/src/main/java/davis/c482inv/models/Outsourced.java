package davis.c482inv.models;

/**
 *Information for outsourced parts
 * @author Brandon Davis
 */
public class Outsourced extends Parts{

    /**
     * The company name for the part
     */

    private String CompanyName;

    /**
     *
     * @param id the ID of part
     * @param name the name of part
     * @param price the price of the part
     * @param stock the number of parts in stock
     * @param min the minimum level of parts
     * @param max the maximum level of parts
     * @param CompanyName the name of the company that makes the part
     */

    public Outsourced(int id, String name, double price, int stock, int min, int max, String CompanyName) {
        super(id, name, price, stock, min, max);
        this.CompanyName = CompanyName;
    }


    /**
     * The getter of the Company Name
     * @return the name of the company
     */
    public String getCompanyName() {
        return CompanyName;
    }
    /**
     * The setter for CompanyName
     * @param CompanyName the name of the company
     */
    public void setCompanyName(String CompanyName) {
        this.CompanyName = CompanyName;
    }



}

