package davis.c482inv.Controllers;

import davis.c482inv.models.Inventory;
import davis.c482inv.models.Parts;
import davis.c482inv.models.Product;
import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Brandon Davis
 */
public class ModifyproductsController implements Initializable {

    /**
     * The product object selected in the MainScreenController.
     */
    Product selectedProduct;
    /**
     * elements of associated parts table
     */
    @FXML
    private TableView<Parts> AssocPartsTableView;

    @FXML
    private TableColumn<Parts, Integer> Associnvlvl;

    @FXML
    private TableColumn<Parts, Integer> AssocpartID;

    @FXML
    private TableColumn<Parts, String> Assocpartname;

    @FXML
    private TableColumn<Parts, Double> Assocpriceperunit;

    @FXML
    private Button Removeassocbutton;

    /**
     * elements of normal parts table
     */

    @FXML
    private TableView<Parts> PartsTableView;

    @FXML
    private TableColumn<Parts, Integer> PartID;

    @FXML
    private TableColumn<Parts, String> PartName;

    @FXML
    private TableColumn<Parts, Double> Priceperunit;

    @FXML
    private TableColumn<Parts, Integer> InvLevel;

    /**
     * all other elements of the products gui
     */


    @FXML
    private Button Cancelbutton;

    @FXML
    private TextField IDtext;

    @FXML
    private TextField InvText;

    @FXML
    private TextField Maxtext;

    @FXML
    private TextField Mintext;

    @FXML
    private TextField Nametext;

    @FXML
    private TextField Pricetext;

    @FXML
    private Button Savebutton;

    @FXML
    private TextField Searchbar;

    @FXML
    private Button Addbutton;
    
    @FXML
    private Button SearchButton;

    private ObservableList<Parts> assocParts = FXCollections.observableArrayList();
    /**
     * Adds part object selected in the all parts table to the associated parts table.
     *
     * Displays error message if no part is selected.
     *
     * @param event Add button action.
     */
    @FXML
    void AddbuttonAction(ActionEvent event) {

        Parts selectedPart = PartsTableView.getSelectionModel().getSelectedItem();

        if (selectedPart == null) {
            displayAlert(5);
        } else {
            assocParts.add(selectedPart);
            AssocPartsTableView.setItems(assocParts);
        }
    }

    /**
     * Displays confirmation dialog and loads MainScreenController.
     *
     * @param event Cancel button action.
     * @throws IOException From FXMLLoader.
     */
    @FXML
    void CancelbuttonAction(ActionEvent event) throws IOException {

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Alert");
        alert.setContentText("Would you like to cancel changes and return to the main screen?");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) {
            returnToMainScreen(event);
        }
    }

    /**
     * Displays confirmation dialog and removes selected part from associated parts table.
     *
     * Displays error message if no part is selected.
     *
     * @param event Remove button action.
     */
    @FXML
    void RemoveassocButtonAction(ActionEvent event) {

        Parts selectedPart = AssocPartsTableView.getSelectionModel().getSelectedItem();

        if (selectedPart == null) {
            displayAlert(5);
        } else {

            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Alert");
            alert.setContentText("Would you like to remove the selected part?");
            Optional<ButtonType> result = alert.showAndWait();

            if (result.isPresent() && result.get() == ButtonType.OK) {
                assocParts.remove(selectedPart);
                AssocPartsTableView.setItems(assocParts);
            }
        }
    }

    /**
     * Replaces product in inventory and loads MainScreenController.
     *
     * Text fields are validated with error messages displayed preventing empty and/or
     * invalid values.
     *
     * @param event Save button action.
     * @throws IOException From FXMLLoader.
     */
    @FXML
    void SavebuttonAction(ActionEvent event) throws IOException {

        try {
            int id = selectedProduct.getId();
            String name = Nametext.getText();
            Double price = Double.parseDouble(Pricetext.getText());
            int stock = Integer.parseInt(InvText.getText());
            int min = Integer.parseInt(Mintext.getText());
            int max = Integer.parseInt(Maxtext.getText());

            if (name.isEmpty()) {
                displayAlert(7);
            } else {
                if (minValid(min, max) && inventoryValid(min, max, stock)) {

                    Product newProduct = new Product(id, name, price, stock, min, max);

                    for (Parts part : assocParts) {
                        newProduct.addAssociatedParts(part);
                    }

                    Inventory.addProduct(newProduct);
                    Inventory.deleteProduct(selectedProduct);
                    returnToMainScreen(event);
                }
            }
        } catch (Exception e){
            displayAlert(1);
        }
    }

    /**
     * Initiates a search based on value in parts search text field and refreshes the parts
     * table view with search results.
     *
     * Parts can be searched for by ID or name.
     *
     * @param event Part search button action.
     */
    @FXML
    void SearchbuttonAction(ActionEvent event) {

        ObservableList<Parts> allParts = Inventory.getPartsList();
        ObservableList<Parts> partsFound = FXCollections.observableArrayList();
        String searchString = Searchbar.getText();

        for (Parts part : allParts) {
            if (String.valueOf(part.getId()).contains(searchString) ||
                    part.getName().contains(searchString)) {
                partsFound.add(part);
            }
        }

        PartsTableView.setItems(partsFound);

        if (partsFound.size() == 0) {
            displayAlert(1);
        }
    }

    /**
     * Refreshes part table view to show all parts when parts search text field is empty.
     *
     * @param event Parts search text field key pressed.
     */
    @FXML
    void SearchbarKeyPressed(KeyEvent event) {

        if (Searchbar.getText().isEmpty()) {
            PartsTableView.setItems(Inventory.getPartsList());
        }
    }

    /**
     * Loads MainScreenController.
     *
     * @param event Passed from parent method.
     * @throws IOException From FXMLLoader.
     */
    private void returnToMainScreen(ActionEvent event) throws IOException {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Mainscreen.fxml"));
        Parent parent = loader.load();
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Validates that min is greater than 0 and less than max.
     *
     * @param min The minimum value for the part.
     * @param max The maximum value for the part.
     * @return Boolean indicating if min is valid.
     */
    private boolean minValid(int min, int max) {

        boolean isValid = true;

        if (min <= 0 || min >= max) {
            isValid = false;
            displayAlert(3);
        }

        return isValid;
    }

    /**
     * Validates that inventory level is equal too or between min and max.
     *
     * @param min The minimum value for the part.
     * @param max The maximum value for the part.
     * @param stock The inventory level for the part.
     * @return Boolean indicating if inventory is valid.
     */
    private boolean inventoryValid(int min, int max, int stock) {

        boolean isValid = true;

        if (stock < min || stock > max) {
            isValid = false;
            displayAlert(4);
        }

        return isValid;
    }

    /**
     * Displays various alert messages.
     *
     * @param alertType Alert message selector.
     */
    private void displayAlert(int alertType) {

        Alert alert = new Alert(Alert.AlertType.ERROR);
        Alert alertInfo = new Alert(Alert.AlertType.INFORMATION);

        switch (alertType) {
            case 1:
                alert.setTitle("Error");
                alert.setHeaderText("Error Modifying Product");
                alert.setContentText("Form contains blank fields or invalid values.");
                alert.showAndWait();
                break;
            case 2:
                alertInfo.setTitle("Information");
                alertInfo.setHeaderText("Part not found");
                alertInfo.showAndWait();
                break;
            case 3:
                alert.setTitle("Error");
                alert.setHeaderText("Invalid value for Min");
                alert.setContentText("Min must be a number greater than 0 and less than Max.");
                alert.showAndWait();
                break;
            case 4:
                alert.setTitle("Error");
                alert.setHeaderText("Invalid value for Inventory");
                alert.setContentText("Inventory must be a number equal to or between Min and Max");
                alert.showAndWait();
                break;
            case 5:
                alert.setTitle("Error");
                alert.setHeaderText("Part not selected");
                alert.showAndWait();
                break;
            case 7:
                alert.setTitle("Error");
                alert.setHeaderText("Name Empty");
                alert.setContentText("Name cannot be empty.");
                alert.showAndWait();
                break;
        }
    }

    /**
     * Initializes controller and populates text fields with product selected in MainScreenController.
     *
     * @param location The location used to resolve relative paths for the root object, or null if the location is not known.
     * @param resources The resources used to localize the root object, or null if the root object was not localized.
     */
    @Override
    public void initialize(URL location, ResourceBundle resources) {

        selectedProduct = MainscreenController.getProducttoModify();
        assocParts = selectedProduct.getAllAssociatedParts();

        PartID.setCellValueFactory(new PropertyValueFactory<>("id"));
        PartName.setCellValueFactory(new PropertyValueFactory<>("name"));
        InvLevel.setCellValueFactory(new PropertyValueFactory<>("stock"));
        Priceperunit.setCellValueFactory(new PropertyValueFactory<>("price"));
        PartsTableView.setItems(Inventory.getPartsList());

        AssocpartID.setCellValueFactory(new PropertyValueFactory<>("id"));
        Assocpartname.setCellValueFactory(new PropertyValueFactory<>("name"));
        Associnvlvl.setCellValueFactory(new PropertyValueFactory<>("stock"));
        Assocpriceperunit.setCellValueFactory(new PropertyValueFactory<>("price"));
        AssocPartsTableView.setItems(assocParts);

        IDtext.setText(String.valueOf(selectedProduct.getId()));
        Nametext.setText(selectedProduct.getName());
        InvText.setText(String.valueOf(selectedProduct.getStock()));
        Pricetext.setText(String.valueOf(selectedProduct.getPrice()));
        Maxtext.setText(String.valueOf(selectedProduct.getMax()));
        Mintext.setText(String.valueOf(selectedProduct.getMin()));
    }

}
