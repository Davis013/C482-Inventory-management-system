package davis.c482inv.Controllers;

import davis.c482inv.models.Inventory;
import davis.c482inv.models.Parts;
import davis.c482inv.models.Product;
import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;
import javafx.scene.input.InputMethodEvent;
import javafx.scene.control.cell.TreeItemPropertyValueFactory;

/**
 *
 * @author Brandon Davis
 */
public class MainscreenController implements Initializable {
    /**
     * The part object selected by the user from the Parts table
     *
     */
    private static Parts PartstoModify;
    /**
     * The product object selected by the user from the Product table
     *
     */
    private static Product ProducttoModify;



    /**
     * Table view of parts table
     *
     */
    @FXML
    private TableView<Parts> PartsTable;

    @FXML
    private TableColumn<Parts, Integer> PartID;

    @FXML
    private TableColumn<Parts, String> PartName;

    @FXML
    private TableColumn<Parts, String> InventoryName;

    @FXML
    private TableColumn<Parts, Double> PriceperUnit;

    @FXML
    private TextField SearchPartID;



    /**
     * Table view of product table
     *
     */
    @FXML
    private TableView<Product> ProductTable;

    @FXML
    private TableColumn<Product, Integer> ProductID;

    @FXML
    private TableColumn<Product, String> ProductName;

    @FXML
    private TableColumn<Product, Integer> InventoryLvl;

    @FXML
    private TableColumn<Product, Double> CostperUnit;

    @FXML
    private TextField SearchProductID;

    /**
     *
     * @return part object
     */
    public static Parts getPartstoModify() {
        return PartstoModify;
    }
    /**
     *
     * @return product object
     */

    public static Product getProducttoModify() {
        return ProducttoModify;
    }

    /**
     * Exits the program.
     *
     */
    @FXML
    void ExitbuttonAction(ActionEvent event) {

        System.exit(0);
    }

    /**
     * Loads the AddPartController.
     *
     * @param event Add button action.
     * @throws IOException From FXMLLoader.
     */
    @FXML
    void partAddAction(ActionEvent event) throws IOException {

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Addparts.fxml"));
        Parent root = loader.load();
        stage.setTitle("Add Part");
        stage.setScene(new Scene(root));
        stage.show();


    }

    /**
     * Deletes the part selected by the user in the part table.
     *
     * The method displays an error message if no part is selected and a confirmation
     * dialog before deleting the selected part.
     *
     * @param event Part delete button action.
     */
    @FXML
    void partDeleteAction(ActionEvent event) {

        Parts selectedPart = PartsTable.getSelectionModel().getSelectedItem();

        if (selectedPart == null) {
            displayAlert(3);
        } else {

            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Alert");
            alert.setContentText("Would you like to delete the selected part?");
            Optional<ButtonType> result = alert.showAndWait();

            if (result.isPresent() && result.get() == ButtonType.OK) {
                Inventory.deletePart(selectedPart);
            }
        }
    }

    /**
     * Loads the ModifyPartController.
     *
     * The method displays an error message if no part is selected.
     *
     * @param event Part modify button action.
     * @throws IOException From FXMLLoader.
     */
    @FXML
    void partModifyAction(ActionEvent event) throws IOException {

        PartstoModify = PartsTable.getSelectionModel().getSelectedItem();

        //Example of correcting a runtime error by preventing null from being passed
        // to the ModifyPartController.
        if (PartstoModify == null) {
            displayAlert(3);
        } else {
            FXMLLoader loader  = new FXMLLoader (getClass().getResource("/Modifyparts.fxml"));
            Parent parent = loader.load();
            Scene scene = new Scene(parent);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        }
    }

    /**
     * Initiates a search based on value in parts search text field and refreshes the parts
     * table view with search results.
     *
     * Parts can be searched for by ID or name.
     *
     * @param event Part search button action.
     */
    @FXML
    void PartsearchBtnAction(ActionEvent event) {

        ObservableList<Parts> allParts = Inventory.getPartsList();
        ObservableList<Parts> FoundParts = FXCollections.observableArrayList();
        String searchString = SearchPartID.getText();

        for (Parts part : allParts) {
            if (String.valueOf(part.getId()).contains(searchString) ||
                    part.getName().contains(searchString)) {
                FoundParts.add(part);
            }
        }

        PartsTable.setItems(FoundParts);

        if (FoundParts.size() == 0) {
            displayAlert(1);
        }
    }

    /**
     * Refreshes part table view to show all parts when parts search text field is empty.
     *
     * @param event Parts search text field key pressed.
     */
    @FXML
    void PartsearchKeyPressed(KeyEvent event) {

        if (SearchPartID.getText().isEmpty()) {
            PartsTable.setItems(Inventory.getPartsList());
        }

    }

    /**
     * Loads AddProductController.
     *
     * @param event Add product button action.
     * @throws IOException From FXMLLoader.
     */
    @FXML
    void productAddAction(ActionEvent event) throws IOException {

        FXMLLoader loader = new FXMLLoader (getClass().getResource("/Addproducts.fxml"));
        Parent parent = loader.load();
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Deletes the product selected by the user in the product table.
     *
     * The method displays an error message if no product is selected and a confirmation
     * dialog before deleting the selected product. Also prevents user from deleting
     * a product with one or more associated parts.
     *
     * @param event Product delete button action.
     */
    @FXML
    void productDeleteAction(ActionEvent event) {

        Product selectedProduct = ProductTable.getSelectionModel().getSelectedItem();

        if (selectedProduct == null) {
            displayAlert(4);
        } else {

            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Alert");
            alert.setContentText("Would you like to delete the selected product?");
            Optional<ButtonType> result = alert.showAndWait();

            if (result.isPresent() && result.get() == ButtonType.OK) {

                ObservableList<Parts> assocParts = selectedProduct.getAllAssociatedParts();

                if (assocParts.size() >= 1) {
                    displayAlert(5);
                } else {
                    Inventory.deleteProduct(selectedProduct);
                }
            }
        }
    }

    /**
     * Loads the ModifyProductController.
     *
     * The method displays an error message if no product is selected.
     *
     * @param event Product modify button action.
     * @throws IOException From FXMLLoader.
     */
    @FXML
    void productModifyAction(ActionEvent event) throws IOException {

        ProducttoModify = ProductTable.getSelectionModel().getSelectedItem();

        if (ProducttoModify == null) {
            displayAlert(4);
        } else {
            FXMLLoader loader  = new FXMLLoader(getClass().getResource("/Modifyproducts.fxml"));
            Parent parent = loader.load();
            Scene scene = new Scene(parent);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        }
    }

    /**
     * Initiates a search based on value in products search text field and refreshes the products
     * table view with search results.
     *
     * Products can be searched for by ID or name.
     *
     * @param event Part search button action.
     */
    @FXML
    void ProductsearchBtnAction(ActionEvent event) {

        ObservableList<Product> allProducts = Inventory.getProductsList();
        ObservableList<Product> FoundProducts = FXCollections.observableArrayList();
        String searchString = SearchProductID.getText();

        for (Product product : allProducts) {
            if (String.valueOf(product.getId()).contains(searchString) ||
                    product.getName().contains(searchString)) {
                FoundProducts.add(product);
            }
        }

        ProductTable.setItems(FoundProducts);

        if (FoundProducts.size() == 0) {
            displayAlert(2);
        }
    }

    /**
     * Refreshes product table view to show all products when products search text field is empty.
     *
     * @param event Products search text field key pressed.
     */
    @FXML
    void ProductsearchKeyPressed(KeyEvent event) {

        if (SearchProductID.getText().isEmpty()) {
            ProductTable.setItems(Inventory.getProductsList());
        }
    }

    /**
     * Displays various alert messages.
     *
     * @param alertType Alert message selector.
     */
    private void displayAlert(int alertType) {

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        Alert alertError = new Alert(Alert.AlertType.ERROR);

        switch (alertType) {
            case 1:
                alert.setTitle("Information");
                alert.setHeaderText("Part not found");
                alert.showAndWait();
                break;
            case 2:
                alert.setTitle("Information");
                alert.setHeaderText("Product not found");
                alert.showAndWait();
                break;
            case 3:
                alertError.setTitle("Error");
                alertError.setHeaderText("Part not selected");
                alertError.showAndWait();
                break;
            case 4:
                alertError.setTitle("Error");
                alertError.setHeaderText("Product not selected");
                alertError.showAndWait();
                break;
            case 5:
                alertError.setTitle("Error");
                alertError.setHeaderText("Parts Associated");
                alertError.setContentText("All parts must be removed from product before deletion.");
                alertError.showAndWait();
                break;
        }
    }

    /**
     * Initializes controller and populates table views.
     *
     * @param location The location used to resolve relative paths for the root object, or null if the location is not known.
     * @param resources The resources used to localize the root object, or null if the root object was not localized.
     */
    @Override
    public void initialize(URL location, ResourceBundle resources) {

        //Populate parts table view
        PartsTable.setItems(Inventory.getPartsList());
        PartID.setCellValueFactory(new PropertyValueFactory<>("id"));
        PartName.setCellValueFactory(new PropertyValueFactory<>("name"));
        InventoryName.setCellValueFactory(new PropertyValueFactory<>("stock"));
        PriceperUnit.setCellValueFactory(new PropertyValueFactory<>("price"));

        //Populate products table view
        ProductTable.setItems(Inventory.getProductsList());
        ProductID.setCellValueFactory(new PropertyValueFactory<>("id"));
        ProductName.setCellValueFactory(new PropertyValueFactory<>("name"));
        InventoryLvl.setCellValueFactory(new PropertyValueFactory<>("stock"));
        CostperUnit.setCellValueFactory(new PropertyValueFactory<>("price"));
    }


}


