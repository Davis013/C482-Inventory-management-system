package davis.c482inv.models;

/**
 *Information for inhouse parts
 * @author Brandon Davis
 */
public class Inhouse extends Parts{

    /**
     * The machine ID for part
     */

    private int MachineID;


    /**
     *
     * @param id the ID for the part
     * @param name the name of the part
     * @param price the price of the part
     * @param stock the number in stock
     * @param min the minimum level for this part
     * @param max the maximum level for this part
     * @param MachineID the machine ID for this part
     */

    public Inhouse(int id, String name, double price, int stock, int min, int max, int MachineID) {
        super(id, name, price, stock, min, max);
        this.MachineID = MachineID; }


    /**
     * The getter for machine ID
     * @return the machine ID for part
     */

    public int getMachineID() {
        return MachineID;
    }


    /**
     * The setter for machine ID
     * @param MachineID the machine ID for this part
     */

    public void setMachineID(int MachineID) {
        this.MachineID = MachineID;
    }

}

