package davis.c482inv.models;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *Products portion for main screen
 *
 * @author Brandon
 */
public class Product {
    private int id;
    private String name;
    private double price;
    private int stock;
    private int min;
    private int max;
    private ObservableList<Parts> associatedParts = FXCollections.observableArrayList();

    /**
     * Constructor for product
     * @param id
     * @param name
     * @param price
     * @param stock
     * @param min
     * @param max
     */

    public Product(int id, String name, double price, int stock, int min, int max) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.stock = stock;
        this.min = min;
        this.max = max;
    }

    /**
     * Getter for ID
     * @return
     */

    public int getId() {
        return id;
    }

    /**
     * Setter for ID
     * @param id
     */

    public void setId(int id) {
        this.id = id;
    }

    /**
     * Getter for Name
     * @return
     */

    public String getName() {
        return name;
    }

    /**
     * Setter for Name
     * @param name
     */

    public void setName(String name) {
        this.name = name;
    }

    /**
     * Getter for Price
     * @return
     */

    public double getPrice() {
        return price;
    }

    /**
     * Setter for Price
     * @param price
     */

    public void setPrice(double price) {
        this.price = price;
    }

    /**
     * Getter for Stock
     * @return
     */

    public int getStock() {
        return stock;
    }

    /**
     * Setter for Stock
     * @param stock
     */

    public void setStock(int stock) {
        this.stock = stock;
    }

    /**
     * Getter for Min
     * @return
     */

    public int getMin() {
        return min;
    }

    /**
     * Setter for Min
     * @param min
     */

    public void setMin(int min) {
        this.min = min;
    }

    /**
     * Getter for Max
     * @return
     */

    public int getMax() {
        return max;
    }

    /**
     * Setter for Max
     *
     * @param max
     */

    public void setMax(int max) {
        this.max = max;
    }

    /**
     * Adds a part to the associated parts list for the product.
     *
     * @param part The part to add
     */
    public void  addAssociatedParts(Parts part) {
        associatedParts.add(part);
    }

    /**
     * Deletes a part from the associated parts list for the product.
     *
     * @param selectedAssociatedParts The part to delete
     * @return a boolean indicating status of part deletion
     */
    public boolean deleteAssociatedParts(Parts selectedAssociatedParts) {
        if (associatedParts.contains(selectedAssociatedParts)) {
            associatedParts.remove(selectedAssociatedParts);
            return true;
        }
        else
            return false;
    }

    /**
     * Gets list of associated parts for the product.
     *
     * @return a list of parts
     */
    public ObservableList<Parts> getAllAssociatedParts() {return associatedParts;}
}
