package davis.c482inv.models;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *Inventory Data
 * @author Brandon Davis
 */
public class Inventory {

    /**
     * An ID for a part. Variable used for unique part IDs.
     */
    private static int PartsID = 0;

    /**
     * An ID for a product. Variable used for unique product IDs.
     */
    private static int ProductID = 0;

    /**
     * A list of all parts in inventory.
     */
    private static ObservableList<Parts> PartsList = FXCollections.observableArrayList();

    /**
     * A list of all products in inventory.
     */
    private static ObservableList<Product> ProductsList = FXCollections.observableArrayList();

    /**
     * Gets a list of all parts in inventory.
     *
     * @return A list of part objects.
     */
    public static ObservableList<Parts> getPartsList() {
        return PartsList;
    }

    /**
     * Gets a list of all products in inventory.
     *
     * @return A list of product objects.
     */
    public static ObservableList<Product> getProductsList() {
        return ProductsList;
    }

    /**
     * Adds a part to the inventory.
     *
     * @param newPart The part object to add.
     */
    public static void addPart(Parts newPart) {
        PartsList.add(newPart);
    }

    /**
     * Adds a product to the inventory.
     *
     * @param newProduct The product object to add.
     */
    public static void addProduct(Product newProduct) {
        ProductsList.add(newProduct);
    }

    /**
     * Generates a new part ID.
     *
     * @return A unique part ID.
     */
    public static int getNewPartId() {
        return PartsID++;
    }

    /**
     * Generates a new product ID.
     *
     * @return A unique product ID.
     */
    public static int getNewProductId() {
        return ProductID++;
    }

    /**
     * Searches the list of parts by ID.
     *
     * @param PartsID The part ID.
     * @return The part object if found, null if not found.
     */
    public static Parts lookupPart(int PartsID) {
        Parts FoundPart = null;

        for (Parts part : PartsList) {
            if (part.getId() == PartsID) {
                FoundPart = part;
            }
        }

        return FoundPart;
    }

    /**
     * Searches the list of parts by name.
     *
     * @param PartsName The part name.
     * @return A list of parts found.
     */
    public static ObservableList<Parts> lookupPart(String PartsName) {
        ObservableList<Parts> FoundParts = FXCollections.observableArrayList();

        for (Parts part : PartsList) {
            if (part.getName().equals(PartsName)) {
                FoundParts.add(part);
            }
        }

        return FoundParts;
    }

    /**
     * Searches the list of products by ID.
     *
     * @param ProductID The product ID.
     * @return The product object if found, null if not found.
     */
    public static Product lookupProduct(int ProductID) {
        Product FoundProduct = null;

        for (Product product : ProductsList) {
            if (product.getId() == ProductID) {
                FoundProduct = product;
            }
        }

        return FoundProduct;
    }

    /**
     * Searches the list of products by name.
     *
     * @param ProductName The product name.
     * @return A list of products found.
     */
    public static ObservableList<Product> lookupProduct(String ProductName) {
        ObservableList<Product> FoundProducts = FXCollections.observableArrayList();

        for (Product product : ProductsList) {
            if (product.getName().equals(ProductName)) {
                FoundProducts.add(product);
            }
        }

        return FoundProducts;
    }

    /**
     * Replaces a part in the list of parts.
     *
     * @param index Index of the part to be replaced.
     * @param selectedPart The part used for replacement.
     */
    public static void updatePart (int index, Parts selectedPart) {

        PartsList.set(index, selectedPart);
    }

    /**
     * Replaces a product in the list of products.
     *
     * @param index Index of the product to be replaced.
     * @param selectedProduct The product used for replacement.
     */
    public static void updateProduct (int index, Product selectedProduct) {

        ProductsList.set(index, selectedProduct);
    }

    /**
     * Removes a part from the list of parts.
     *
     * @param selectedPart The part to be removed.
     * @return A boolean indicating status of part removal.
     */
    public static boolean deletePart(Parts selectedPart) {
        if (PartsList.contains(selectedPart)) {
            PartsList.remove(selectedPart);
            return true;
        }
        else {
            return false;
        }
    }

    /**
     * Removes a product from the list of parts.
     *
     * @param selectedProduct The product to be removed.
     * @return A boolean indicating status of product removal.
     */
    public static boolean deleteProduct(Product selectedProduct) {
        if (ProductsList.contains(selectedProduct)) {
            ProductsList.remove(selectedProduct);
            return true;
        }
        else {
            return false;
        }
    }
}

